import pygame
import random

# Initialize Pygame
pygame.init()

# Set up display
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Airplane Shooting Game")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

# Game variables
player_size = 50
player_speed = 5
enemy_size = 50
enemy_speed = 3
bullet_size = 10
bullet_speed = 7
enemy_spawn_delay = 60  # Number of frames between enemy spawns

# Load images
player_img = pygame.image.load('player.png')
player_img = pygame.transform.scale(player_img, (player_size, player_size))
enemy_img = pygame.image.load('enemy.png')
enemy_img = pygame.transform.scale(enemy_img, (enemy_size, enemy_size))
bullet_img = pygame.Surface((bullet_size, bullet_size))
pygame.draw.circle(bullet_img, RED, (bullet_size // 2, bullet_size // 2), bullet_size // 2)

# Font
font = pygame.font.Font(None, 36)

# Sounds
pygame.mixer.music.load('background_music.mp3')
pygame.mixer.music.set_volume(0.5)
bullet_sound = pygame.mixer.Sound('bullet_sound.mp3')
bullet_sound.set_volume(0.5)

# Clock
clock = pygame.time.Clock()

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = player_img
        self.rect = self.image.get_rect(center=(WIDTH // 2, HEIGHT - player_size // 2))

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= player_speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += player_speed

    def shoot(self):
        bullet = Bullet(self.rect.centerx, self.rect.top)
        all_sprites.add(bullet)
        bullets.add(bullet)
        bullet_sound.play()

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = enemy_img
        self.rect = self.image.get_rect(center=(random.randint(enemy_size // 2, WIDTH - enemy_size // 2), 0))

    def update(self):
        self.rect.y += enemy_speed
        if self.rect.top > HEIGHT:
            self.rect.y = 0
            self.rect.centerx = random.randint(enemy_size // 2, WIDTH - enemy_size // 2)

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = bullet_img
        self.rect = self.image.get_rect(center=(x, y))

    def update(self):
        self.rect.y -= bullet_speed
        if self.rect.bottom < 0:
            self.kill()

# Sprite groups
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()
bullets = pygame.sprite.Group()

# Create player
player = Player()
all_sprites.add(player)

# Game variables
score = 0

# Play background music
pygame.mixer.music.play(loops=-1)

# Game loop
running = True
enemy_spawn_counter = 0
while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.shoot()

    # Spawn enemies
    enemy_spawn_counter += 1
    if enemy_spawn_counter == enemy_spawn_delay:
        enemy_spawn_counter = 0
        enemy = Enemy()
        all_sprites.add(enemy)
        enemies.add(enemy)

    # Update sprites
    all_sprites.update()

    # Check for collisions
    hits = pygame.sprite.groupcollide(enemies, bullets, True, True)
    for hit in hits:
        enemy = Enemy()
        all_sprites.add(enemy)
        enemies.add(enemy)
        score += 1

    hits = pygame.sprite.spritecollide(player, enemies, False)
    if hits:
        running = False

    # Draw sprites
    all_sprites.draw(screen)

    # Draw score
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
